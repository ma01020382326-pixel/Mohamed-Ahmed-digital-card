import { lazy, Suspense, useState } from 'react'
import Profile from './components/Profile'
import Skills from './components/Skills'
import SocialLinks from './components/SocialLinks'
import { profile } from './config'

const Contact = lazy(() => import('./components/Contact'))
const QRCode = lazy(() => import('./components/QRCode'))

export default function App() {
  const [modal, setModal] = useState(null)
  const close = () => setModal(null)

  return (
    <>
      <main className="container">
        <Profile onContact={() => setModal('contact')} onQR={() => setModal('qr')} />
        <Skills />
        <SocialLinks />
      </main>
      <footer className="footer">
        <p>© {new Date().getFullYear()} {profile.name}</p>
      </footer>
      <Suspense fallback={null}>
        {modal === 'contact' && <Contact onClose={close} />}
        {modal === 'qr' && <QRCode onClose={close} />}
      </Suspense>
    </>
  )
}

// Single place to edit all personal info, links and skills.

export const profile = {
  name: 'Mohamed Ahmed Adel',
  title: 'React Frontend Developer',
  education: 'Second-Year Baccalaureate Student',
  bio: '16-year-old student and aspiring React Frontend Developer, passionate about programming, modern web technologies, and building creative digital experiences.',
  availability: 'Open to connect',
}

// Leave empty to use the address the site is actually served from (recommended).
// Set it only after your final domain is confirmed, e.g. 'https://mohamed-ahmed.vercel.app'
export const siteUrl = ''

// Only https:// links are accepted (see safeUrl below). Remove an entry to hide it.
export const socials = [
  { id: 'whatsapp', label: 'WhatsApp', url: 'https://wa.me/201020382336' },
  { id: 'facebook', label: 'Facebook', url: 'https://www.facebook.com/profile.php?id=61577167635568' },
  { id: 'instagram', label: 'Instagram', url: 'https://www.instagram.com/mahamed__2010_/?hl=ar' },
  { id: 'tiktok', label: 'TikTok', url: 'https://www.tiktok.com/@mmmxm1234' },
  { id: 'github', label: 'GitHub', url: 'https://github.com/ma01020382326-pixel' },
]

// Listed in the Contact Me window, in this order.
export const contactIds = ['whatsapp', 'instagram', 'facebook']

export const skills = [
  { name: 'React', short: 'Re', depth: 1.4 },
  { name: 'JavaScript', short: 'JS', depth: 0.8 },
  { name: 'TypeScript', short: 'TS', depth: 1.8 },
  { name: 'HTML', short: 'H5', depth: 1.1 },
  { name: 'CSS', short: 'C3', depth: 1.6 },
  { name: 'Tailwind CSS', short: 'Tw', depth: 0.9 },
  { name: 'Vite', short: 'Vi', depth: 1.5 },
  { name: 'Git', short: 'Gi', depth: 1.0 },
  { name: 'GitHub', short: 'Gh', depth: 1.7 },
]

export function safeUrl(url) {
  try {
    return new URL(url).protocol === 'https:' ? url : null
  } catch {
    return null
  }
}

export const validSocials = socials.filter((s) => safeUrl(s.url))
export const byId = (id) => validSocials.find((s) => s.id === id)

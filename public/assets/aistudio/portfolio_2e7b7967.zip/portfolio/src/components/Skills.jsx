import { useEffect, useRef } from 'react'
import { skills } from '../config'

export default function Skills() {
  const ref = useRef(null)

  useEffect(() => {
    const el = ref.current
    const canTrack = window.matchMedia('(hover: hover) and (pointer: fine) and (min-width: 900px)').matches
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (!el || !canTrack || reduced) return

    let frame = 0
    const move = (e) => {
      cancelAnimationFrame(frame)
      frame = requestAnimationFrame(() => {
        const r = el.getBoundingClientRect()
        el.style.setProperty('--mx', ((e.clientX - r.left) / r.width - 0.5).toFixed(3))
        el.style.setProperty('--my', ((e.clientY - r.top) / r.height - 0.5).toFixed(3))
      })
    }
    const reset = () => {
      el.style.setProperty('--mx', 0)
      el.style.setProperty('--my', 0)
    }
    el.addEventListener('pointermove', move)
    el.addEventListener('pointerleave', reset)
    return () => {
      cancelAnimationFrame(frame)
      el.removeEventListener('pointermove', move)
      el.removeEventListener('pointerleave', reset)
    }
  }, [])

  return (
    <section className="section" aria-labelledby="skills-title">
      <h2 id="skills-title" className="section-title">Skills</h2>
      <ul className="pills" ref={ref}>
        {skills.map((s, i) => (
          <li key={s.name} style={{ '--d': s.depth, '--k': i }}>
            <span className="pill">
              <b aria-hidden="true">{s.short}</b>
              {s.name}
            </span>
          </li>
        ))}
      </ul>
    </section>
  )
}

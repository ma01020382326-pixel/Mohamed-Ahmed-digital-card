import { validSocials } from '../config'
import { Icon, brandColors } from './icons'

export default function SocialLinks() {
  return (
    <section className="section" aria-labelledby="social-title">
      <h2 id="social-title" className="section-title">Find me online</h2>
      <ul className="socials">
        {validSocials.map((s) => (
          <li key={s.id}>
            <a className="social-card" href={s.url} target="_blank" rel="noopener noreferrer">
              <Icon name={s.id} size={26} color={brandColors[s.id]} />
              <span>{s.label}</span>
              <span className="sr-only"> (opens in a new tab)</span>
            </a>
          </li>
        ))}
      </ul>
    </section>
  )
}

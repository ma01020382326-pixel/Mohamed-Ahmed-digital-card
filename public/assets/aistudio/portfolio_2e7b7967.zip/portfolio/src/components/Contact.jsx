import { contactIds, byId } from '../config'
import { Icon, brandColors } from './icons'
import Modal from './Modal'

export default function Contact({ onClose }) {
  const items = contactIds.map(byId).filter(Boolean)
  return (
    <Modal title="Contact Me" onClose={onClose}>
      <p className="muted">Pick whichever is easiest for you.</p>
      <ul className="contact-list">
        {items.map((s) => (
          <li key={s.id}>
            <a className="social-card row" href={s.url} target="_blank" rel="noopener noreferrer">
              <Icon name={s.id} size={24} color={brandColors[s.id]} />
              <span>{s.label}</span>
              <span className="sr-only"> (opens in a new tab)</span>
            </a>
          </li>
        ))}
      </ul>
    </Modal>
  )
}

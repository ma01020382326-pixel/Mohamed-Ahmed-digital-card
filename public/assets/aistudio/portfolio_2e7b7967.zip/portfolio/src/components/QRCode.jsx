import { useEffect, useState } from 'react'
import { siteUrl } from '../config'
import Modal from './Modal'

export default function QRCode({ onClose }) {
  const url = siteUrl || window.location.origin + '/'
  const [src, setSrc] = useState('')
  const [copied, setCopied] = useState('')

  useEffect(() => {
    let alive = true
    import('qrcode').then(({ default: QR }) =>
      QR.toDataURL(url, { width: 512, margin: 2, color: { dark: '#1D4ED8', light: '#FFFFFF' } }).then(
        (data) => alive && setSrc(data),
      ),
    )
    return () => {
      alive = false
    }
  }, [url])

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(url)
      setCopied('Link copied')
    } catch {
      setCopied('Copy failed — select the link manually')
    }
    setTimeout(() => setCopied(''), 2500)
  }

  return (
    <Modal title="QR Code" onClose={onClose}>
      <div className="qr-box">
        {src ? <img src={src} width="220" height="220" alt={`QR code linking to ${url}`} /> : <div className="qr-skeleton" />}
      </div>
      <p className="muted center">Scan to visit my profile</p>
      <p className="url">{url}</p>
      <div className="actions">
        {src && (
          <a className="btn btn-primary" href={src} download="mohamed-ahmed-qr.png">
            Download QR
          </a>
        )}
        <button className="btn btn-ghost" onClick={copy}>
          Copy Profile Link
        </button>
      </div>
      <p className="muted center" role="status" aria-live="polite">{copied}</p>
    </Modal>
  )
}

import { profile, byId } from '../config'
import { Icon } from './icons'

// Drop your photo at src/assets/profile.webp (or .avif/.jpg/.png). Missing file = placeholder.
const photos = import.meta.glob('../assets/profile.{webp,avif,jpg,jpeg,png}', {
  eager: true,
  import: 'default',
})
const photo = Object.values(photos)[0]

const dots = Array.from({ length: 14 }, (_, i) => i)
const letters = Array.from(profile.name)

export default function Profile({ onContact, onQR }) {
  const github = byId('github')

  return (
    <header className="hero">
      <div className="avatar-wrap">
        <div className="particles" aria-hidden="true">
          {dots.map((i) => (
            <span key={i} style={{ '--i': i }} />
          ))}
        </div>
        <div className="avatar-ring">
          {photo ? (
            <img
              src={photo}
              width="320"
              height="320"
              alt={`Portrait of ${profile.name}`}
              fetchPriority="high"
              decoding="async"
            />
          ) : (
            <div className="avatar-placeholder" role="img" aria-label="Profile photo placeholder">
              MA
            </div>
          )}
        </div>
        <span className="status">
          <i aria-hidden="true" /> {profile.availability}
        </span>
      </div>

      <h1 className="vapor" aria-label={profile.name}>
        {letters.map((ch, i) => (
          <span
            key={i}
            aria-hidden="true"
            style={{ '--i': i, '--t': i / (letters.length - 1) }}
          >
            {ch === ' ' ? '\u00A0' : ch}
          </span>
        ))}
      </h1>
      <p className="role">{profile.title}</p>
      <p className="edu">{profile.education}</p>
      <p className="bio">{profile.bio}</p>

      <div className="actions">
        <button className="btn btn-primary" onClick={onContact}>
          Contact Me
        </button>
        {github && (
          <a className="btn btn-ghost" href={github.url} target="_blank" rel="noopener noreferrer">
            <Icon name="github" size={18} /> View GitHub
          </a>
        )}
        <button className="btn btn-ghost" onClick={onQR}>
          <Icon name="qr" size={18} /> QR Code
        </button>
      </div>
    </header>
  )
}

# Mohamed Ahmed Adel – Portfolio (React + Vite)

## Run
    npm install
    npm run dev
    npm run build

## Edit content
Everything personal lives in `src/config.js` (name, bio, links, skills, site URL).
Photo: put it at `src/assets/profile.webp` (convert to WebP, ~640px wide is plenty).

## Deploy
Push to GitHub -> import in Vercel (framework: Vite, build `npm run build`, output `dist`).
Then set `siteUrl` in config (optional) and add canonical/og:url in `index.html`.

## Measure performance
Open the deployed URL in Chrome Incognito -> DevTools -> Lighthouse -> Mobile -> Performance.
